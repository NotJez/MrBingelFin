const Discord = require("discord.js")
const bot = new Discord.Client()
const config = require("./config.json")


bot.on("ready", () => {
    console.log("Olen aktiivinen!!")
});




bot.on("message", message => {
    if (message.author.bot) return;
    if (message.content.indexOf(config.prefix) !== 0) return;

    const args = message.content.slice(config.prefix.length).trim().split(/ +/g);
    const command = args.shift().toLowerCase()

    if (command === "komennot") {
        const helpEmbed = new Discord.MessageEmbed()
            .setTitle(`${bot.user.username} Kommennot`)
            .setDescription(`**Prefixi:** ${config.prefix}`)
            .addField(`\`ping\``, `Katsoo Mr. Bingelin Pingin.`)
            .addField(`\`potki\``, `Käytetään: **${config.prefix}potki [@käyttäjä]**\n**${config.prefix}kick [@käyttäjä][syy]**`)
            .addField(`\`porttikielto\``, `Käytetään: **${config.prefix}porttikielto [@käyttäjä]**\n**${config.prefix}ban [@käyttäjä][syy]**`)
            .addField(`\`poista\``, `Poistaa 2-100 viestiä \nKäytetään: **${config.prefix}poista [numero]**`)
            .addField(`\`sano\``, `Saa botin sanomaan mitä haluat.`)
        message.channel.send(helpEmbed)
    }

    if (command === "ping") {
        message.channel.send(`Pong! **(${Date.now() - message.createdTimestamp}ms)**`)
    }

    if (command === "potki") {
        if (!message.member.hasPermission('KICK_MEMBERS'))
            return message.channel.send("Ei oikeuksia. (Tarvittavat oikeudet: 'Poista jäseniä')").then(msg => {
        msg.delete({ timeout: 30000 })
    })
        const member = message.mentions.members.first();
        if (!member)
            return message.channel.send("Et ole maininnut käyttäjää.").then(msg => {
        msg.delete({ timeout: 30000 })
    })
        if (!member.kickable)
            return message.channel.send("Et voi potkia tätä käyttäjää").then(msg => {
        msg.delete({ timeout: 30000 })
    })
        const reason = args.slice(1).join(" ")
        if (member) {
            if (!reason) return member.kick().then(member => {
                message.channel.send(`${member.user.tag} potkittiin ulos Bingelistä, mutta ilman mitään syytä :o.`);
            })

            if (reason) return member.kick().then(member => {
                message.channel.send(`${member.user.tag} potkittiin ulos syystä ${reason}`);
            })
        }
    }

    if (command === "porttikielto") {
        if (!message.member.hasPermission('BAN_MEMBERS'))
            return message.channel.send("Ei oikeuksia. (Tarvittavat oikeudet: 'Anna porttikieltoja')").then(msg => {
        msg.delete({ timeout: 30000 })
    })
        const member = message.mentions.members.first();
        if (!member)
            return message.channel.send("Et ole maininnut käyttäjää.").then(msg => {
        msg.delete({ timeout: 30000 })
    })
        if (!member.bannable)
            return message.channel.send("Tälle käyttäjälle et voi antaa porttikieltoja.").then(msg => {
        msg.delete({ timeout: 30000 })
    })
        const reason = args.slice(1).join(" ")
        if (member) {
            if (!reason) return member.ban().then(member => {
                message.channel.send(`${member.user.tag} sai porttikiellon Bingeliin, mutta ilman mitään syytä :o.`);
            })

            if (reason) return member.ban(reason).then(member => {
                message.channel.send(`${member.user.tag} sai porttikiellon syystä ${reason}`);
            })
        }
    }

    if (command === "sano") {
    const text = args.join(" ")
    if(!text) return message.channel.send("Et ole kirjoittanut tekstiä mitä minä sanoisin.").then(msg => {
        msg.delete({ timeout: 30000 })
    })
    message.channel.send(text)
    
    }
   
    if (command === "poista") {
    if(!message.member.hasPermission('MANAGE_MESSAGES')) return message.channel.send("Ei oikeuksia. (Tarvittavat oikeudet: `Määrää viestejä`)").then(msg => {
        msg.delete({ timeout: 30000 })
    })
    const number = args.join(" ")
    if(!number) return message.channel.send("Et ole sanonut lukua jota poistaisin.").then(msg => {
        msg.delete({ timeout: 30000 })
    })
   message.channel.bulkDelete(number).catch(console.error)
   
   }

});

bot.login(config.token)